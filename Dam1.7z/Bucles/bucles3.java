package bucles5;
public class Ejercicio5_3 {
    public static void main(String args[]){
    int a=0;
    
    while (a<100){
    a=a+5;
    System.out.println(a);
    }
}}
