package ap5_bucles;

public class Ejercicio_2 {

    public static void main(String[] args) {
        int cont = 0;

        while (cont <= 100) {
            System.out.println(cont + " es múltiplo de 5");

            cont += 5;
        }
    }
}
