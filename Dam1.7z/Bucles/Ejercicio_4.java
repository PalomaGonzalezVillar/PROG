
package ejerciciosbucles;



public class Ejercicio_4 {
    public static void main(String[] args) {
        for (int a=320; a>=160; a-=20){
            System.out.println(a);
        }
    }
}
