
package ejerciciosbucles;


public class Ejercicio_3 {
    public static void main(String[] args) {
        int a=0;
           do {
               a+=5;
               System.out.println(a);
            } while (a<100);
    }
}
