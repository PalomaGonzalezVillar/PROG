package ejerciciosbucles;
public class bucles6 {
    public static void main(String[] args) {
        int a=320;
        do {
            System.out.println(a);
            a=a-20;
        }
        while (a > 159);
    }
}
