package ejerciciosbucles;
public class bucles5 {
    public static void main(String[] args) {
        int a=320;
        while (a>=160) {
            System.out.println(a);
            a=a-20;//a-=20;
        }
    }
}
