/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package segundoprojecto;

import java.util.Scanner;

/**
 *
 * @author DAM133
 */
public class ejercio17 {
    public static void main(String[] args) {
        Scanner Leer=new Scanner(System.in);
        double a=Leer.nextDouble();
        double resto=Leer.nextDouble();
        resto= a%10;
        System.out.println("el resto es "+ resto );
        
        
         
    }
    
}
